#include <iostream>
// ========================= YOUR CODE HERE =========================
// Define the Food, Utensil, and Spoon classes here. 
// Refer to the README for instructions.
// ===================================================================